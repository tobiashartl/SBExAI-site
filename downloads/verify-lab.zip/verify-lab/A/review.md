# The New Jersey–Pennsylvania study and the debate that followed (draft section)

On April 1, 1992, New Jersey raised its minimum wage from $4.25 to $5.05 per hour, while
the minimum wage in neighbouring Pennsylvania stayed the same. @card1994 surveyed 410
fast-food restaurants, 331 in New Jersey and 79 in eastern Pennsylvania, shortly before
and about eight months after the increase. Comparing the change in full-time-equivalent
(FTE) employment between the two states, they find that employment in New Jersey rose
relative to Pennsylvania. In the balanced sample of stores observed in both waves, the
difference-in-differences estimate is 2.75 FTE employees per store (s.e. 1.34), and our
replication reproduces this number (`output/table3.csv`). They found no indication that
the higher minimum wage reduced employment, in line with an earlier study of fast-food
restaurants in Texas [@katz1992].

The study was disputed. Using payroll records collected from a sample of the same
restaurant chains, @neumark2000 found that employment in New Jersey fell relative to
Pennsylvania. In their reply, @card2000 used establishment data from the Bureau of Labor
Statistics and found that employment in New Jersey grew as fast as or slightly faster than
in Pennsylvania.

Later work moved from case studies to many state-level changes. Comparing contiguous
county pairs on either side of state borders, @dube2010 find no detectable employment
losses in restaurants and other low-wage sectors. @neumark2014 argue that such designs
discard informative variation and report negative employment effects for teenagers. Using the number of jobs just below and above the new minimum wage,
@cengiz2019 find that the overall number of low-wage jobs remained essentially unchanged
in the five years after an increase.
