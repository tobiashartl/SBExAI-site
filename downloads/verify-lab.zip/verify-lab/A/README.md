# Draft section to check

`review.md` is a draft section of a literature review on minimum wages, written quickly
with AI help. `refs.bib` is its bibliography. `output/table3.csv` holds the replicated
numbers from Card and Krueger (1994), Table 3.

The draft has not been checked.
