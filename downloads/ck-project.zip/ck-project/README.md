# Course project: minimum wages and employment

You work in this folder all day. By the end you have:

1. **A replication** of Table 3 of Card and Krueger (1994), in R, with the numbers in `output/`.
2. **A short literature review** (`review/review.qmd`, 2–4 pages) on the employment effects
   of minimum wages, built around that paper. Every citation is checked; every number
   comes from `output/`.
3. **A few slides** presenting both (`slides/slides.qmd`, made in Block 4).

## Sources (download them in Block 1; they are not included here)

| What | Where | Put it in |
|------|-------|-----------|
| The paper: Card, D. and Krueger, A. B. (1994). Minimum wages and employment: A case study of the fast-food industry in New Jersey and Pennsylvania. *American Economic Review*, 84(4), 772–793. | <https://davidcard.berkeley.edu/papers/njmin-aer.pdf> | `paper/` |
| The data: survey of 410 fast-food restaurants, with codebook and the original SAS program | <https://davidcard.berkeley.edu/data_sets/njmin.zip> (unzip) | `data/raw/` |

Both are provided by David Card on his website. Do not redistribute them.

## Folders

```
paper/        the article (PDF)
data/raw/     original data, never edited
R/            R scripts, numbered, run from this folder
output/       everything the scripts produce (tables as CSV)
review/       review.qmd and refs.bib (the bibliography)
slides/       slides.qmd (Block 4)
```

## Render the review

Open `review/review.qmd` in VS Code and click **Preview** (Quarto extension), or ask
Claude to render it.

## Your own paper instead

If you have a paper with a public replication package, you may use it instead. It
should have one main table you can reproduce, and data you are allowed to use with
an AI tool.
